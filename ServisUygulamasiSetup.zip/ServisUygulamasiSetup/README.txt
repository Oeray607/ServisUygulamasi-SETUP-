#############################################################
#                                                           #
#         SERVİS ÜCRETİ HESAPLAMA - KURULUM TALİMATLARI     #
#                                                           #
#############################################################

Merhaba! Servis Ücreti Hesaplama uygulamasını kurmak için aşağıdaki 
adımları izlemeniz yeterlidir.

-------------------------------------------------------------

KURULUM ADIMLARI


1.  Bu klasörün içinde bulunan "setup.exe" dosyasına çift tıklayın.

2.  Karşınıza bir güvenlik uyarısı penceresi çıkabilir. Bu, programın 
    henüz Microsoft tarafından resmi olarak tanınmamasından kaynaklanan
    normal bir durumdur. Güvenle "Yükle" (Install) butonuna basarak
    devam edebilirsiniz.

3.  Eğer bilgisayarınızda uygulamanın çalışması için gerekli olan 
    .NET 8 altyapısı eksikse, kurulum sizi yönlendirerek 
    indirip kurmanızı isteyecektir. Lütfen bu adımı onaylayın.

4.  Kurulum tamamlandığında, uygulama otomatik olarak başlayacaktır.
    Ayrıca Başlat Menüsü'nde programın bir kısayolunu bulabilirsiniz.


-------------------------------------------------------------
OLASI SORUNLAR


* "Bilinmeyen Yayımcı" (Unknown Publisher) uyarısı: Bu uyarı, 
    güvenlik sertifikasının test amaçlı olmasından kaynaklanır ve
    tamamen normaldir. "Yükle" diyerek devam edebilirsiniz.

* Windows SmartScreen uyarısı: Bazı durumlarda Windows, uygulamayı
    engellemek isteyebilir. Böyle bir ekranda "Ek Bilgi" (More info) 
    linkine, ardından "Yine de çalıştır" (Run anyway) butonuna 
    tıklamanız gerekebilir.


-------------------------------------------------------------

Teşekkürler!